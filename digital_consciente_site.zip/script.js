function aumentarFonte() {
  document.body.style.fontSize = "22px";
}

function modoAltoContraste() {
  document.body.classList.toggle("high-contrast");
}

function mudarIdioma(idioma) {
  if (idioma === "en") {
    document.querySelector(".hero h2").textContent = "Welcome to Digital Consciente";
    document.querySelector(".hero p").textContent = "Safe browsing is a right for everyone.";
    document.querySelector("#dicas h2").textContent = "Digital Citizenship Tips";
    document.querySelector("#dicas ul").innerHTML = `
      <li>Use strong and unique passwords.</li>
      <li>Be careful with suspicious messages.</li>
      <li>Enable two-step verification.</li>
      <li>Avoid clicking unknown links.</li>
      <li>Have reliable antivirus software.</li>
    `;
    document.querySelector("#acessibilidade h2").textContent = "Accessibility Tools";
    document.querySelector("#idiomas h2").textContent = "Language";
  } else {
    document.querySelector(".hero h2").textContent = "Bem-vindo ao Digital Consciente";
    document.querySelector(".hero p").textContent = "Navegar com segurança é um direito de todos.";
    document.querySelector("#dicas h2").textContent = "Dicas de Cidadania Digital";
    document.querySelector("#dicas ul").innerHTML = `
      <li>Use senhas fortes e únicas.</li>
      <li>Desconfie de mensagens suspeitas.</li>
      <li>Ative a verificação em duas etapas.</li>
      <li>Evite clicar em links desconhecidos.</li>
      <li>Tenha um antivírus confiável.</li>
    `;
    document.querySelector("#acessibilidade h2").textContent = "Ferramentas de Acessibilidade";
    document.querySelector("#idiomas h2").textContent = "Idioma";
  }
}
